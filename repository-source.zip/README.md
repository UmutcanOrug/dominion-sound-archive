# Dominion Sound Archive

Persistent audio libraries for individual Foundry VTT **Actors and Items**, including Items embedded inside Actors and synthetic token Actors. Built for **Foundry V13 (target build 351)** and SWADE, with The Forge Assets Library as the preferred file source. No combat modules or API keys are required.

**Testing status:** automated service and adapter tests pass against mocks. The module has **not** been tested inside a running Foundry V13.351/SWADE/Forge world. `compatibility.verified` declares the intended core target, not a claim of completed in-game testing. Follow [TESTING.md](TESTING.md) before relying on it in a campaign.

## Install on The Forge

1. Open [The Forge Bazaar](https://forge-vtt.com/bazaar) and click **Install From Manifest** (or Foundry Setup → Add-on Modules → Install Module, if available for your hosting configuration).
2. Paste this **manifest URL**, then install:

   ```text
   https://github.com/UmutcanOrug/dominion-sound-archive/releases/latest/download/module.json
   ```

3. Launch your world. In **Game Settings → Manage Modules**, enable **Dominion Sound Archive** and save.
4. Open an Actor or Item sheet and click **Sound Archive** in its window header. The same button works for an inventory Item opened from its Actor sheet.

The [release](https://github.com/UmutcanOrug/dominion-sound-archive/releases/latest) includes `module.json` and `dominion-sound-archive.zip`. The manifest's `manifest` URL points to the latest release asset; its `download` URL points to the versioned ZIP. You do not need to download and re-upload audio files.

For local Foundry installation, extract the ZIP into `Data/modules/dominion-sound-archive/`. The ZIP has `module.json` at its root. Do not use GitHub's automatically generated **Source code (zip)** as the installation manifest or package.

## Prototype groups (1.0.4)

As GM, open **Configure Settings → Dominion Sound Archive → Prototype voice** or **Prototype weapon**. These world settings start with the seven voice and nine weapon groups listed below. Use **Add Group** to add as many rows as needed, enter a display name and a unique **voice.*** or **weapon.*** category key, then **Save**. Only group names and keys are shared; sounds and folders stay in each sheet’s own archive. Blank/duplicate names, duplicate keys, wrong prefixes and the reserved legacy **voice.movement** key are rejected before saving.

Save immediately applies missing groups to world Actors, world Items, Actor inventories and unlinked token Actors/inventories on every scene, using the elected active GM. No Forge refresh is normally required. New/imported/duplicated documents and owner-opened archives use the current prototype. A GM reload retries unfinished application. Compendium packs are not mass-scanned or unlocked; their imported documents receive defaults.

**Preservation and duplicate rules:** exact category key wins; otherwise a group with the same name ignoring case and extra whitespace is reused. Its existing ID, display name, custom category key, files, folders, cached clips, labels, exclusions and order are kept. A name match with no key receives the prototype key. A name match with an existing custom key retains that key; macros for that sheet must continue using its actual key. Already duplicated local groups are kept rather than destructively consolidated.

Synchronization adds missing groups only. It never deletes, renames or replaces existing sheet groups. Editing a prototype name affects newly created groups; an existing keyed group keeps its local name. Changing a key may add a group only where neither its key nor its name matches. Removing a prototype row stops future additions but leaves all existing copies and sounds intact. Use **Cancel** or close the window to discard an unsaved draft. Saving a stale draft after another GM changes that same prototype is rejected; reopen and merge your edits. Simultaneous writes from different clients still follow Foundry’s normal last-write-wins behavior.

## Use the archive

The initial voice prototype contains these seven groups:

| Group | Macro category key |
| --- | --- |
| `attack` | `voice.attack` |
| `take cover` | `voice.take-cover` |
| `enter building` | `voice.enter-building` |
| `move` | `voice.move` |
| `run` | `voice.run` |
| `wounded` | `voice.wounded` |
| `retreat` | `voice.retreat` |

After updating, reload the world as a GM. One active GM automatically adds missing groups to every world Actor and existing unlinked scene token Actor. Newly created, imported and duplicated Actors receive them during creation. Existing Item groups are preserved alongside the new defaults below.

Version **1.0.3** replaces the old default `movement` group with `move` and `run`. On a GM reload or owner-opened archive, groups keyed `voice.movement` and unkeyed groups named `movement` migrate into `move` (`voice.move`). Their audio files, folder references and cached clips are retained; a new `run` (`voice.run`) pool starts empty. If a `move` pool already exists, legacy references merge into it. Different entries with colliding IDs are retained with distinct IDs. Existing custom display names and explicitly customized category keys are preserved. Existing run sounds remain in the run pool.

For compatibility, Actor `listClips`/`getRandomClip` calls filtered by `voice.movement` fall back to `voice.move` when no original legacy category remains. New macros should use `voice.move` and `voice.run`; macros that inspect raw `getLibrary().groups` must use the new keys themselves.

Other existing groups, IDs, labels, cached folders and sound references are preserved. A matching category key, or a matching name ignoring case/extra spaces, is reused. Matching groups without a category receive the key above; existing custom keys are preserved. Owner-opened archives also fill missing defaults. Default groups remain editable; if removed, missing defaults return the next time an owner opens the archive or a GM reloads the world. Unopened compendium packs are not scanned or unlocked; imported Actors receive defaults normally.

Starting with **1.0.2**, all Items receive nine default weapon audio groups:

| Group | Macro category key |
| --- | --- |
| `Bolt-Action` | `weapon.bolt-action` |
| `Semi-Auto` | `weapon.semi-auto` |
| `LMG` | `weapon.lmg` |
| `HMG` | `weapon.hmg` |
| `Sub-Machine` | `weapon.sub-machine` |
| `Pistol` | `weapon.pistol` |
| `Cannon` | `weapon.cannon` |
| `Reload` | `weapon.reload` |
| `Explosion` | `weapon.explosion` |

Reload as a GM after updating to initialize world Items and equipment embedded in every world Actor and existing unlinked scene token Actor. Newly created/imported/duplicated Items receive defaults during creation; initial equipment supplied with a newly created/imported Actor is also initialized. Owners can fill missing defaults by opening an Item's archive. Existing matching groups, custom keys and all audio references are preserved using the same rules as Actor groups.

Each category is a separate sound pool on the same Item. For example, `api.getRandomClip(equipment, {category: "weapon.bolt-action"})` and `api.getRandomClip(equipment, {category: "weapon.hmg"})` let a future squad macro request four bolt-action shots and two HMG shots. A tank macro can select `weapon.hmg` and `weapon.cannon`. The macro supplies the equipment counts. Existing `weapon.fire` groups remain available to older macros; using the new pools requires selecting their category keys.

- **Add Group:** enter a display name and, optionally, a unique machine key such as `weapon.fire`, `weapon.reload`, `voice.attack`, or `voice.reload`.
- **Add Audio File:** opens the host's native audio FilePicker. Select an existing file in **The Forge Assets**. Choose its display name and optional label, then save.
- **Add Folder:** opens the native folder FilePicker. Navigate into the directory and select it. Name it and optionally enable **Include subfolders**. Recursion is off by default.
- Expand a folder to see and preview each clip. Counts show the number of cached, visible audio files. Multiple folders and individual clips can share a group.
- **Refresh Folder:** replaces the cached list with the current directory contents. Failed scans preserve the previous cache. No background scans occur when reopening a sheet.
- Use the pencil to rename a group, entry or custom label. Use arrows or drag handles to reorder groups or entries within their current group.
- **Play** previews locally; clicking again stops it. Starting another preview stops the previous one across all archive windows. Closing the preview's window also stops it.
- Search matches clip names, labels and paths, and folder names. Changes save automatically to the associated document.
- Removing an entry removes its reference only. Hiding a folder clip records an exclusion that survives refreshes. To restore excluded clips, remove and reattach that folder. Removing a group requires confirmation.

The module never uploads, moves or deletes assets. The original files remain in the Assets Library. All clip references are independent per document, so an Actor and its embedded weapon may organize the same file differently. Normal Foundry duplication/export retains flags.

English labels are the default. Turkish translations are included and follow Foundry's language setting.

## Permissions and limitations

**Observer** or higher is required to inspect and preview an archive. Editing also requires document ownership, Foundry's `canUserModify(user, "update")`, and an unlocked compendium. Asset browsing permissions remain governed by Foundry and Forge. Owners without FilePicker access cannot add or refresh folders until granted the appropriate native permission.

Supported filename extensions: OGG/OGA, MP3, WAV, WEBM, M4A, AAC, FLAC and OPUS. A matching extension does not guarantee that a browser supports the file's codec. Missing, inaccessible or unsupported assets produce an error on playback.

Folder scans are limited to 5,000 audio references per folder and 100 directories per recursive User Data scan. Forge recursion uses one `browse` request; User Data scans are sequential with a visited-directory guard. Link narrower folders for large archives. Cached flags are part of each document and count toward its storage size.

Writes within one client are queued and re-read current flags. Simultaneous edits by different users follow Foundry's normal last-write-wins behavior; coordinate editing of the same archive. Future schema versions are rejected without overwriting data. No earlier schema needs migration in this first release.

No attack detection, automatic playback, recording, broadcasting or spatial sound is included.

## Public macro API

Available after Foundry's `ready` hook:

```js
const api = game.modules.get("dominion-sound-archive").api;
```

All document arguments must be saved **Actor or Item instances**, not IDs or names. Embedded Items are fully supported: use `actor.items.get(itemId)` or `actor.items.find(...)`. Their own flags are read and updated through Foundry's embedded-document methods. For a synthetic token Actor, pass `token.actor` and that Actor's Items.

| Method | Result |
| --- | --- |
| `await api.openArchive(document)` | Opens/reuses the document's archive window; resolves to its application. |
| `api.getLibrary(document)` | Independent copy of `{schemaVersion: 1, groups: [...]}`. Does not modify flags. |
| `api.listClips(document, options = {})` | Flat array of individual playable clip references, including cached folder clips. |
| `api.getRandomClip(document, options = {})` | Uniformly selected clip reference or `null` for an empty result. Does not play it. |
| `await api.refreshFolder(document, entryId)` | Rescans a folder and saves its refreshed cache; returns the updated folder entry. Requires ownership. |

`listClips` and `getRandomClip` accept `{groupId, category, search}`. Filters combine; `groupId` is the stable generated group ID, while `category` is the optional user-defined machine key. A missing category returns `[]`/`null`. `search` is case-insensitive.

Clip metadata:

```js
{
  documentUuid: "Actor.ACTOR_ID.Item.ITEM_ID",
  groupId: "stable-group-id",
  groupName: "Weapon Fire",
  category: "weapon.fire",
  entryId: "stable-file-or-folder-id",
  folderId: null, // folder entry ID for a clip resolved from a folder
  name: "Fire_01.ogg",
  path: "https://assets.forge-vtt.com/USER_ID/weapons/Fire_01.ogg",
  label: ""
}
```

Example (also provided as [an importable Script macro](examples/random-weapon-and-voice.js)):

```js
const api = game.modules.get("dominion-sound-archive").api;
const soldier = canvas.tokens.controlled[0]?.actor;
const weapon = soldier?.items.find(i => i.name === "Valterion Mk.2");
if (soldier && weapon) {
  const fire = api.getRandomClip(weapon, {category: "weapon.fire"});
  const voice = api.getRandomClip(soldier, {category: "voice.attack"});
  console.log({fire, voice}); // either may be null; no audio is played
}
```

Methods throw descriptive errors for invalid documents, insufficient permissions, unavailable sources and unsupported schemas. Catch errors in macros. Audio references are cached; the API does not verify asset existence on every read.

## Development and releases

No build step or runtime npm dependencies are needed. Use Node 22+:

```sh
node --test
node tools/validate.mjs
```

For a new release, update `version`, the versioned `download` URL, package version, release notes and changelog together. Run the tests and validator, then package the module with `module.json` at the ZIP root and upload both files to a new versioned GitHub release.

Architecture: `sheet-integration.js` handles V1/V2 hooks and a header-only fallback; `archive-app.js` owns the V2 application; `library-service.js` enforces permissions and persists flags; `forge-browser.js` resolves the configured V13 picker implementation and scans files; `audio-preview.js` manages one local HTML audio element; `api.js` exposes the read/refresh interface.

## API references used

- [Foundry V13 header control entries](https://foundryvtt.com/api/v13/interfaces/foundry.applications.types.ApplicationHeaderControlsEntry.html)
- [Foundry V13 FilePicker and its configured implementation](https://foundryvtt.com/api/v13/classes/foundry.applications.apps.FilePicker.html)
- [Foundry V13 ApplicationV2](https://foundryvtt.com/api/v13/classes/foundry.applications.api.ApplicationV2.html)
- [The Forge: FilePicker Assets Library integration and recursive browsing](https://forums.forge-vtt.com/t/using-the-filepicker-to-interact-with-the-assets-library/98008)

This module contains no Foundry or SWADE proprietary assets and is not an official Pinnacle or Foundry product.




Settings API reference: [Foundry V13 ClientSettings](https://foundryvtt.com/api/v13/classes/foundry.helpers.ClientSettings.html).
