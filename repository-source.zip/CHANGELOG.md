# Changelog

## 1.0.7

- Recognize public weapon attack cards from the SWADE Tools 2.3.0 fork alongside native SWADE attacks.
- Match parts of Actor or token names. When several rules supply audio for the same event, the longest matching rule wins.
- Play Death when Incapacitated is applied, including when the combat tracker leaves Defeated unset.
- Prefer each Actor's own Attack, Hurt or Death pool when it contains clips. Supply those groups to Actor archives and support legacy Wounded clips as a Hurt fallback.

## 1.0.6

- Fixed Automatic Sound Matching controls remaining disabled after adding a sound set in Foundry.
- Added the Sound Archive file and folder workflow to Attack, Hurt and Death, including individual preview, refresh and clip exclusions.
- Existing 1.0.5 sound paths load as individual clips.

## 1.0.5

- Added Automatic Sound Matching for SWADE. GMs assign Attack, Hurt and Death audio pools to character names in Configure Settings.
- Plays one clip from the matching pool for public weapon attacks, increased Wounds, and tokens marked Dead or Defeated. Audio uses Foundry's interface channel and goes to clients viewing the scene. Hidden tokens only broadcast to GMs.
- Added checks for exact name matching, linked and unlinked token events, private rolls, repeated defeat notifications and saving the GM menu.

## 1.0.4 — 2026-10-22

- Added GM-only Prototype voice and Prototype weapon menus in Configure Settings, with world-persistent group names and category keys and no fixed group count. Initial definitions match 1.0.3.
- Save applies missing groups to world Actors/Items, embedded equipment and unlinked token Actors/equipment. Creation/import/duplication and owner-opened archives use current definitions.
- Reuse a category key or normalized name without duplicating groups. Keep existing custom keys, names, IDs and every sound/folder reference. Removed/edited prototypes never delete or rename existing sheet groups.
- Validate all rows before writes; reject stale editor drafts, preserve unsaved input on failure, lock controls during redraw/save and retry failed document updates without resetting archives.
- Verified with 61 automated module tests and browser UI checks in a mock Foundry shell. Live Foundry/Forge testing remains pending.

## 1.0.3

- Replaced the Actor default `movement` with separate `move` (`voice.move`) and `run` (`voice.run`) groups.
- Migrates legacy movement files and folder references into move while creating a separate run pool. Existing move pools merge without losing references; repeat initialization is idempotent.
- Preserves custom category keys and renamed display labels. Legacy Actor API category filters for `voice.movement` fall back to `voice.move` after migration.
- Added eight migration/compatibility tests; all 39 module tests pass locally with mocks. Item weapon groups remain unchanged.

## 1.0.2

- Item archives now start with `Bolt-Action`, `Semi-Auto`, `LMG`, `HMG`, `Sub-Machine`, `Pistol`, `Cannon`, `Reload` and `Explosion`, each with a separate `weapon.*` category key.
- New world/embedded Items initialize automatically. One elected GM backfills world Items and equipment on all world Actors and unlinked scene token Actors. Initial equipment on newly created/imported Actors and new unlinked tokens is also initialized.
- Existing groups, IDs, sound references and `weapon.fire` compatibility are preserved. Actor and Item defaults share an additive initialization service.
- Added eleven automated tests for Item creation, migrations, permissions, recovery and mixed squad/tank sound pools; all 31 module tests pass locally with mocks.

## 1.0.1

- Actors now start with `attack`, `take cover`, `enter building`, `movement`, `wounded` and `retreat` groups, each with a macro category key.
- New/imported/duplicated Actors receive defaults during creation. One elected GM backfills world Actors and existing unlinked scene token Actors when the world opens; owners can also initialize missing defaults by opening an archive.
- Existing matching groups and all archived sounds are preserved. Repeated initialization does not duplicate groups; Item libraries remain unchanged.
- Added nine automated tests for creation, migration, permissions, duplicate prevention and failure recovery.

## 1.0.0

- Independent, persistent Actor and Item audio archives with versioned document flags.
- Legacy and ApplicationV2 sheet header controls, including embedded Items.
- Custom groups and machine keys; file/folder selection, refresh, search and ordering.
- Forge Assets priority and single-request recursive folder scans with cached playable URLs.
- Local-only preview shared across archive windows; source assets remain untouched.
- Ownership checks, English/Turkish localization and a documented public macro API.
- Automated mocked service/adapter tests and an explicit manual Foundry acceptance checklist.
