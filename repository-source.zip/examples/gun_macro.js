// =====================================================
// SPACE ODDYSEY - SINGLE TOKEN SQUAD FIRE
// 1 Squad Token = 12 Virtual Soldiers
// Bolt-Action Rifle Fire / Multi-Sound / Random Timing
// =====================================================

const EFFECT_FILE = "jb2a.bullet.01.orange";

// =====================================================
// SOUND CONFIGURATION
// Add as many sound files as you want.
// =====================================================

const SOUND_FILES = [
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_01.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_04.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_06.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_07.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_08.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_09.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_10.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_mid_01.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_mid_02.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_mid_03.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_mid_04.wav",
  "https://assets.forge-vtt.com/62f57b3e2579d0a019e346d6/new_sounds_domi_wargame/razinsk_rifle/m9130_rifle_mid_05.wav",
];

const SOUND_VOLUME = 0.5;

// =====================================================
// VOICE FOLDER CONFIGURATION
// =====================================================

// Forge Assets Library folder.
// Enter the FOLDER path, not an individual audio file.
// Example: "Space Ships/SquadVoices"

const VOICE_SOURCE = "forgevtt";
const VOICE_FOLDER = "new_sounds_domi_wargame/razinsk_chatter/classic_infantry";

// Voice volume.
const VOICE_VOLUME = 0.60;

// Random voice lines per macro execution.
const MIN_VOICE_COUNT = 1;
const MAX_VOICE_COUNT = 3;

// First voice line starts after a random delay.
const VOICE_START_MIN_MS = 0;
const VOICE_START_MAX_MS = 300;

// Time between voice line STARTS.
// Overlapping voices are allowed.
const VOICE_INTERVAL_MIN_MS = 2000;
const VOICE_INTERVAL_MAX_MS = 3000;

// =====================================================
// SQUAD CONFIGURATION
// =====================================================

const SQUAD_SIZE = 12;
const SHOTS_PER_SOLDIER = 2;

// Bolt-action rifle firing cadence.
const MIN_SHOT_DELAY_MS = 2500;
const MAX_SHOT_DELAY_MS = 4000;

// Each soldier starts independently.
const MIN_START_DELAY_MS = 0;
const MAX_START_DELAY_MS = 2500;

// Occasional aiming pause.
const PAUSE_CHANCE = 0.15;
const MIN_PAUSE_MS = 1000;
const MAX_PAUSE_MS = 2000;

// =====================================================
// PROJECTILE CONFIGURATION
// =====================================================

const SOURCE_SPREAD_RATIO = 0.40;

const MISS_CHANCE = 0.66;

const TARGET_RANDOM_OFFSET_RATIO = 0.48;
const MISS_SIDE_OFFSET_RATIO = 0.65;
const MISS_EXTENSION_GRID_SPACES = 10;

const PROJECTILE_SIZE = 0.1;

// =====================================================
// VALIDATION
// =====================================================

if (!game.modules.get("sequencer")?.active) {
  ui.notifications.error(
    "Sequencer module is not active."
  );
  return;
}

const selectedTokens = canvas.tokens.controlled;
const targets = Array.from(game.user.targets);

if (selectedTokens.length !== 1) {
  ui.notifications.warn(
    "Select exactly ONE squad token."
  );
  return;
}

if (targets.length !== 1) {
  ui.notifications.warn(
    "Target exactly ONE enemy token."
  );
  return;
}

const weaponSounds = SOUND_FILES.filter(
  path => typeof path === "string" && path.trim()
);

if (weaponSounds.length === 0) {
  ui.notifications.error(
    "No weapon sounds configured."
  );
  return;
}

const source = selectedTokens[0];
const target = targets[0];

// =====================================================
// LOAD VOICE FILES FROM FOLDER
// =====================================================

let voiceSounds = [];

// Supported audio extensions.
const AUDIO_EXTENSIONS =
  /\.(mp3|ogg|wav|webm|m4a|flac|opus)$/i;

function isAudioFile(path) {
  if (typeof path !== "string") return false;

  // Remove query strings from the extension check.
  const cleanPath = path.split(/[?#]/)[0];

  try {
    return AUDIO_EXTENSIONS.test(
      decodeURIComponent(cleanPath)
    );
  } catch {
    return AUDIO_EXTENSIONS.test(cleanPath);
  }
}

try {

  // Scan the Forge Assets Library.
  // Forge supports recursive folder browsing.
  const folderResult = await FilePicker.browse(
    VOICE_SOURCE,
    VOICE_FOLDER,
    { recursive: true }
  );

  // Collect all supported audio files.
  voiceSounds = [
    ...new Set(
      (folderResult.files || []).filter(isAudioFile)
    )
  ];

  console.log(
    `[Space Oddysey] Loaded ${voiceSounds.length} voice files.`,
    voiceSounds
  );

  if (voiceSounds.length === 0) {
    ui.notifications.warn(
      "No audio files found in the voice folder. Firing will continue without voices."
    );
  }

} catch (error) {

  console.error(
    "[Space Oddysey] Voice folder error:",
    error
  );

  ui.notifications.warn(
    "Could not browse the voice folder. Firing will continue without voices."
  );
}

// =====================================================
// RANDOM UTILITIES
// =====================================================

function randomInt(min, max) {
  return Math.floor(
    Math.random() * (max - min + 1)
  ) + min;
}

function randomFloat(min, max) {
  return Math.random() * (max - min) + min;
}

// =====================================================
// SHUFFLE BAG
// Used independently for weapon and voice sounds.
// =====================================================

function createSoundPicker(files) {

  let bag = [];
  let lastIndex = -1;

  return function pickSound() {

    if (bag.length === 0) {

      bag = files.map((_, i) => i);

      // Fisher-Yates shuffle.
      for (let i = bag.length - 1; i > 0; i--) {

        const j = randomInt(0, i);

        [bag[i], bag[j]] =
          [bag[j], bag[i]];
      }

      // Avoid repeating the previous sound
      // at the start of a new shuffle cycle.
      if (
        bag.length > 1 &&
        bag[bag.length - 1] === lastIndex
      ) {

        const swapIndex = bag.findIndex(
          index => index !== lastIndex
        );

        if (swapIndex !== -1) {

          const last = bag.length - 1;

          [bag[last], bag[swapIndex]] =
            [bag[swapIndex], bag[last]];
        }
      }
    }

    const index = bag.pop();

    lastIndex = index;

    return files[index];
  };
}

// =====================================================
// SOURCE OFFSET
// Virtual soldiers fire from different positions.
// =====================================================

function randomSourceOffset() {

  return {
    x: randomFloat(
      -source.w * SOURCE_SPREAD_RATIO,
      source.w * SOURCE_SPREAD_RATIO
    ),
    y: randomFloat(
      -source.h * SOURCE_SPREAD_RATIO,
      source.h * SOURCE_SPREAD_RATIO
    )
  };
}

// =====================================================
// HIT OFFSET
// =====================================================

function randomHitOffset() {

  return {
    x: randomFloat(
      -target.w * TARGET_RANDOM_OFFSET_RATIO,
      target.w * TARGET_RANDOM_OFFSET_RATIO
    ),
    y: randomFloat(
      -target.h * TARGET_RANDOM_OFFSET_RATIO,
      target.h * TARGET_RANDOM_OFFSET_RATIO
    )
  };
}

// =====================================================
// MISS OFFSET
// =====================================================

function randomMissOffset() {

  const from = source.center;
  const to = target.center;

  const distance = Math.hypot(
    to.x - from.x,
    to.y - from.y
  ) || 1;

  const dx = (to.x - from.x) / distance;
  const dy = (to.y - from.y) / distance;

  const perpX = -dy;
  const perpY = dx;

  const side = Math.random() < 0.5 ? -1 : 1;

  const targetSize = Math.max(
    target.w,
    target.h
  );

  const sideOffset = randomFloat(
    targetSize * 0.30,
    targetSize * MISS_SIDE_OFFSET_RATIO
  );

  const forwardJitter = randomFloat(
    -targetSize * 0.15,
    targetSize * 0.15
  );

  const extension = Math.max(
    targetSize * 0.75,
    (canvas.grid.size || 100) *
      MISS_EXTENSION_GRID_SPACES
  );

  return {
    x:
      perpX * side * sideOffset +
      dx * (forwardJitter + extension),

    y:
      perpY * side * sideOffset +
      dy * (forwardJitter + extension)
  };
}

// =====================================================
// GENERATE SQUAD FIRING SCHEDULE
// =====================================================

const shots = [];

for (
  let soldier = 0;
  soldier < SQUAD_SIZE;
  soldier++
) {

  // One fixed firing position per virtual soldier.
  const muzzleOffset = randomSourceOffset();

  let firingTime = randomInt(
    MIN_START_DELAY_MS,
    MAX_START_DELAY_MS
  );

  for (
    let shot = 0;
    shot < SHOTS_PER_SOLDIER;
    shot++
  ) {

    if (shot > 0) {

      // Bolt cycling and aiming delay.
      firingTime += randomInt(
        MIN_SHOT_DELAY_MS,
        MAX_SHOT_DELAY_MS
      );

      // Occasional longer pause.
      if (Math.random() < PAUSE_CHANCE) {

        firingTime += randomInt(
          MIN_PAUSE_MS,
          MAX_PAUSE_MS
        );
      }
    }

    shots.push({
      delay: firingTime,
      muzzleOffset,
      isMiss: Math.random() < MISS_CHANCE
    });
  }
}

// Sort shots in chronological order.
shots.sort((a, b) => a.delay - b.delay);

// =====================================================
// BUILD WEAPON FIRING SEQUENCE
// =====================================================

const pickWeaponSound = createSoundPicker(weaponSounds);

const fireSequence = new Sequence();

for (const shot of shots) {

  const targetOffset = shot.isMiss
    ? randomMissOffset()
    : randomHitOffset();

  fireSequence
    .effect()
      .file(EFFECT_FILE)
      .atLocation(source, {
        offset: shot.muzzleOffset,
        gridUnits: false
      })
      .stretchTo(target, {
        offset: targetOffset,
        gridUnits: false
      })
      .spriteScale(PROJECTILE_SIZE)
      .delay(shot.delay)
      .playbackRate(1.2)
      .randomizeMirrorY()
      .missed(false)

    .sound()
      .file(pickWeaponSound())
      .delay(shot.delay)
      .volume(SOUND_VOLUME);
}

// =====================================================
// RANDOM VOICE LINE SYSTEM
// =====================================================

// Independent from weapon fire.
// Voice lines may overlap.
// Every voice starts 1-2 seconds after the previous.

if (voiceSounds.length > 0) {

  const pickVoice = createSoundPicker(voiceSounds);

  const voiceSequence = new Sequence();

  // Random number of voice lines.
  const voiceCount = randomInt(
    MIN_VOICE_COUNT,
    MAX_VOICE_COUNT
  );

  // Absolute start time of first voice.
  let voiceTime = randomInt(
    VOICE_START_MIN_MS,
    VOICE_START_MAX_MS
  );

  for (let i = 0; i < voiceCount; i++) {

    if (i > 0) {

      // 1-2 second interval between starts.
      voiceTime += randomInt(
        VOICE_INTERVAL_MIN_MS,
        VOICE_INTERVAL_MAX_MS
      );
    }

    // Pick a random voice from the folder pool.
    const voiceFile = pickVoice();

    voiceSequence
      .sound()
        .file(voiceFile)
        .delay(voiceTime)
        .volume(VOICE_VOLUME);
  }

  // Start voice lines independently.
  voiceSequence.play();
}

// =====================================================
// START SQUAD FIRING
// =====================================================

fireSequence.play();